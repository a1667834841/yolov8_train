# xxqg验证码识别 > 2024-07-17 3:02pm
https://universe.roboflow.com/ssc-sdc/xxqg-yho7d

Provided by a Roboflow user
License: CC BY 4.0

