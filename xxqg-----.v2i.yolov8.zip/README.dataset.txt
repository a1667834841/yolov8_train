# xxqg验证码识别 > 2024-07-21 7:22am
https://universe.roboflow.com/xxqg/xxqg-yho7d

Provided by a Roboflow user
License: CC BY 4.0

